
public class CycleException extends Exception {

}
