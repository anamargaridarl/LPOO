
public class DuplicateNameException extends Exception {

}
